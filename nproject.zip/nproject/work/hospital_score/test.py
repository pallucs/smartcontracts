import osi 
from insurance_score import Insurance


i = Insurance()
i.claim()
