#from insurance_score.insurance_score import Insurance
from iconservice import *
#import sys

TAG = 'Hospital'
#sys.path.append('/work/insurance_score')
#from insurance_score import Insurance

class Hospital(IconScoreBase):

    def __init__(self, db: IconScoreDatabase) -> None:
        super().__init__(db)

    def on_install(self) -> None:
        super().on_install()

    def on_update(self) -> None:
        super().on_update()
    
    @external(readonly=True)
    def feeClearance(self) -> str:
	from insurance_score import Insurance
        #spec = importlib.util.spec_from_file_location("module.name", "/work/insurance_score/insurance_score.py")
        #module = importlib.util.module_from_spec(spec)
        #spec.loader.exec_module(module)
        insurance = Insurance()
        return insurance.claim()
