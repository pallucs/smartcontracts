from iconservice import *

TAG = 'Insurance'

class Insurance(IconScoreBase):

    def __init__(self, db: IconScoreDatabase) -> None:
        super().__init__(db)

    def on_install(self) -> None:
        super().on_install()

    def on_update(self) -> None:
        super().on_update()
    
    @external(readonly=True)
    def checkInsurance(self) -> str:
        return "Palistha"
    @external(readonly=True)
    def claim(self) -> str:
        return "No"
