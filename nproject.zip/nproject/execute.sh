
docker stop nproject
docker rm nproject
docker run -it --name=nproject -v nproject_vol:/work -p 9000:9000 iconloop/tbears:mainnet
