docker cp nproject:/work /home/palistha/Desktop/nproject
